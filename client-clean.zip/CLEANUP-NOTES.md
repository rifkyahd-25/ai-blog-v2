# Cleanup notes

- Removed ~1,850 lines of commented-out dead code (old duplicate versions of
  components/pages left in as comments) across 15 files.
- Centralized every backend API call behind `src/utils/apiConfig.js`
  (`API_BASE_URL`, defaults to `http://localhost:3000`). Previously calls were
  split three ways: hardcoded `https://blogbackend-b9ww.onrender.com`, bare
  relative `"api/..."` (broken — resolves against the current page path), and
  root-relative `"/api/..."` (only worked via the Vite dev proxy). All three
  now go through one constant.
- Fixed `ShareButtons .jsx` → `ShareButtons.jsx` (the file had a literal
  trailing space in its name; fragile across filesystems/git).
- Removed unused dependencies: `@tiptap/*`, `react-quill`,
  `quill-delta-to-html`, `html2canvas` — none were imported anywhere.
- Cleaned `.env` down to the active keys only (was full of commented-out
  history/duplicates).
- **Added `.env` to `.gitignore` — it was missing.** If this repo was ever
  pushed to git before now, your Firebase key and Cloudinary credentials may
  be in the commit history; worth checking and rotating if so.
- `vite.config.js` already has a dev proxy (`/api` → `localhost:3000`) — it's
  now redundant since every call uses an absolute `API_BASE_URL`, but it's
  harmless to leave in.

Not removed, but worth knowing:
- The `/job` feature (`CreateJob`, `JobListings`, `UpdateJob`, `DashJob`,
  the "Jobs" nav link) has no matching backend — the backend zip you gave me
  has no `job.model.js` / `job.controller.js` / `job.route.js`. It'll 404
  until you add those (mirroring the `post.*` files is the fastest path).
- `getall`'s `.select("title summary image category slug createdAt")` selects
  a `summary` field that doesn't exist in `post.model.js` — it'll always come
  back `undefined`. Not touched since it's a schema/feature decision, not
  cleanup, but flagging it since it's probably not intentional.
