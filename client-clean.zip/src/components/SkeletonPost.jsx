export default function SkeletonPost() {
    return (
      <div className="animate-pulse p-4 max-w-4xl mx-auto w-full">
        {/* Title */}
        <div className="h-8 bg-gray-300 rounded w-3/4 mx-auto mb-6"></div>
  
        {/* Image placeholder */}
        <div className="w-full h-64 sm:h-[400px] bg-gray-300 rounded-lg mb-6"></div>
  
        {/* Paragraph blocks */}
        <div className="space-y-4">
          <div className="h-4 bg-gray-300 rounded w-full"></div>
          <div className="h-4 bg-gray-300 rounded w-5/6"></div>
          <div className="h-4 bg-gray-300 rounded w-4/6"></div>
        </div>
  
        {/* Recent Articles Section */}
        <div className="mt-10">
          <div className="h-6 bg-gray-300 rounded w-1/3 mb-4"></div>
          <div className="flex gap-5 flex-wrap justify-center">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="w-72 h-40 bg-gray-300 rounded-lg"
              ></div>
            ))}
          </div>
        </div>
      </div>
    );
  }
  