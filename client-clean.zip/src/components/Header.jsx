import {
  Avatar,
  Button,
  Dropdown,
  Navbar,
  TextInput,
} from "flowbite-react";
import React, { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { AiOutlineSearch } from "react-icons/ai";
import { FaMoon, FaSun } from "react-icons/fa";
import { useSelector, useDispatch } from "react-redux";
import { toggleTheme } from "../redux/theme/themeSlice";
import { signoutSuccess } from "../redux/user/userSlice";
import { API_BASE_URL } from "../utils/apiConfig";

export default function Header() {
  const path = useLocation().pathname;
  const location = useLocation();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const dispatch = useDispatch();
  const { currentUser } = useSelector((state) => state.user);
  const { theme } = useSelector((state) => state.theme);

  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const searchTermFromUrl = urlParams.get("searchTerm");
    if (searchTermFromUrl) setSearchTerm(searchTermFromUrl);
  }, [location.search]);

  const handleSignout = async () => {
    try {
      const res = await fetch(
        `${API_BASE_URL}/api/user/signout`,
        { method: "POST" }
      );
      const data = await res.json();
      if (!res.ok) console.log(data.message);
      else dispatch(signoutSuccess());
    } catch (error) {
      console.log(error.message);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const urlParams = new URLSearchParams(location.search);
    urlParams.set("searchTerm", searchTerm);
    navigate(`/search?${urlParams.toString()}`);
  };

  return (
    <Navbar className="bg-blue-900 text-white shadow-md">
      <div className="w-full max-w-7xl mx-auto flex items-center justify-between px-4 py-3">
        {/* Brand */}
        <Link
          to="/"
          className="flex items-center gap-2 text-xl sm:text-2xl font-bold"
        >
          <span className="px-4 py-1.5 bg-yellow-500 rounded-xl text-black shadow">
            RRR
          </span>
          <span className="text-white sm:text-lg">Blog</span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-8 font-medium text-white">
          {[
            { name: "Home", path: "/" },
            { name: "Blog", path: "/search" },
            { name: "Jobs", path: "/job" },
            { name: "About", path: "/about" },
            { name: "Contact", path: "/contact" },
          ].map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`hover:text-yellow-400 transition ${
                path === link.path ? "text-yellow-400" : ""
              }`}
            >
              {link.name}
            </Link>
          ))}
        </div>

        {/* Right side */}
        <div className="flex items-center gap-3 md:gap-4">
          {/* Search */}
          <form onSubmit={handleSubmit} className="hidden lg:flex">
            <TextInput
              type="text"
              placeholder="Search..."
              rightIcon={AiOutlineSearch}
              className="w-64 rounded-lg bg-white/10 placeholder-white/70 text-white focus:ring-2 focus:ring-yellow-500 focus:bg-white/20"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </form>

          {/* Mobile search */}
          <Button className="w-10 h-10 lg:hidden bg-white/20 hover:bg-white/30 text-white" pill>
            <AiOutlineSearch size={18} />
          </Button>

          {/* Theme toggle */}
          <Button
            className="w-10 h-10 bg-white/10 hover:bg-white/20 text-white"
            pill
            onClick={() => dispatch(toggleTheme())}
            title="Toggle theme"
          >
            {theme === "light" ? <FaSun /> : <FaMoon />}
          </Button>

          {/* Auth */}
          {currentUser ? (
            <Dropdown
              arrowIcon={false}
              inline
              label={<Avatar alt="user" img={currentUser.profilePicture} rounded />}
            >
              <Dropdown.Header>
                <span className="block text-sm font-semibold">
                  @{currentUser.username}
                </span>
                <span className="block text-xs text-gray-500 truncate">
                  {currentUser.email}
                </span>
              </Dropdown.Header>
              <Link to="/dashboard?tab=profile">
                <Dropdown.Item>Profile</Dropdown.Item>
              </Link>
              <Dropdown.Divider />
              <Dropdown.Item onClick={handleSignout}>Sign out</Dropdown.Item>
            </Dropdown>
          ) : (
            <Link to="/sign-in">
              <Button className="bg-yellow-500 hover:bg-yellow-600 text-black font-medium rounded-lg px-4 py-2">
                Login
              </Button>
            </Link>
          )}

          {/* Mobile menu toggle */}
          <Navbar.Toggle className="md:hidden text-white" />
        </div>
      </div>

      {/* Mobile nav */}
      <Navbar.Collapse className="md:hidden bg-blue-900 text-white">
        <Navbar.Link active={path === "/"} as="div">
          <Link to="/">Home</Link>
        </Navbar.Link>
        <Navbar.Link active={path === "/search"} as="div">
          <Link to="/search">Blog</Link>
        </Navbar.Link>
        <Navbar.Link active={path === "/job"} as="div">
          <Link to="/job">Jobs</Link>
        </Navbar.Link>
        <Navbar.Link active={path === "/contact"} as="div">
          <Link to="/contact">Contact</Link>
        </Navbar.Link>
        <Navbar.Link active={path === "/contact"} as="div">
          <Link to="/about">About</Link>
        </Navbar.Link>
      </Navbar.Collapse>
    </Navbar>
  );
}
