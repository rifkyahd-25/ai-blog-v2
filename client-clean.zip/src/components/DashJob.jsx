import { Modal, Table, Button } from "flowbite-react";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { HiOutlineExclamationCircle } from "react-icons/hi";
import { API_BASE_URL } from "../utils/apiConfig";

export default function DashJob() {
  const { currentUser } = useSelector((state) => state.user);
  const [jobs, setJobs] = useState([]);
  const [showMore, setShowMore] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [jobIdToDelete, setJobIdToDelete] = useState("");

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/api/job/getall`);
        const data = await res.json();
        if (res.ok) {
          setJobs(data.jobs || []);
          if (data.jobs.length < 9) {
            setShowMore(false);
          }
        }
      } catch (error) {
        console.log(error.message);
      }
    };
    if (currentUser.isAdmin) {
      fetchJobs();
    }
  }, [currentUser.isAdmin]);

  const handleDeleteJob = async () => {
    setShowModal(false);
    try {
      const res = await fetch(
        `${API_BASE_URL}/api/job/delete/${jobIdToDelete}/${currentUser._id}`,
        { method: "DELETE" }
      );
      if (res.ok) {
        setJobs((prev) => prev.filter((job) => job._id !== jobIdToDelete));
      }
    } catch (error) {
      console.log(error.message);
    }
  };

  const handleShowMore = async () => {
    const startIndex = jobs.length;
    try {
      const res = await fetch(`${API_BASE_URL}/api/job/getall?startIndex=${startIndex}`);
      const data = await res.json();
      if (res.ok) {
        setJobs((prev) => [...prev, ...data.jobs]);
        if (data.jobs.length < 9) {
          setShowMore(false);
        }
      }
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <div>
      {currentUser.isAdmin && jobs.length > 0 ? (
        <>
          <Table>
            <Table.Head>
              <Table.HeadCell>Date Posted</Table.HeadCell>
              <Table.HeadCell>Logo</Table.HeadCell>
              <Table.HeadCell>Job Title</Table.HeadCell>
              <Table.HeadCell>Company</Table.HeadCell>
              <Table.HeadCell>Location</Table.HeadCell>
              <Table.HeadCell>Type</Table.HeadCell>
              <Table.HeadCell>Delete</Table.HeadCell>
              <Table.HeadCell>Edit</Table.HeadCell>
            </Table.Head>

            <Table.Body className="divide-y">
              {jobs.map((job) => (
                <Table.Row
                  key={job._id}
                  className="bg-white dark:border-gray-700 dark:bg-gray-800"
                >
                  <Table.Cell>
                    {new Date(job.createdAt).toLocaleDateString()}
                  </Table.Cell>
                  <Table.Cell>
                    <img
                      src={job.logo || "/default-logo.png"}
                      alt={job.company}
                      className="w-16 h-10 object-contain bg-gray-200 p-1 rounded"
                    />
                  </Table.Cell>
                  <Table.Cell className="font-medium text-gray-900 dark:text-white">
                    {job.title}
                  </Table.Cell>
                  <Table.Cell>{job.company}</Table.Cell>
                  <Table.Cell>{job.location || "Remote"}</Table.Cell>
                  <Table.Cell>{job.type}</Table.Cell>
                  <Table.Cell>
                    <span
                      onClick={() => {
                        setShowModal(true);
                        setJobIdToDelete(job._id);
                      }}
                      className="text-red-500 hover:underline cursor-pointer"
                    >
                      Delete
                    </span>
                  </Table.Cell>
                  <Table.Cell>
                    <Link
                      className="text-teal-500 hover:underline"
                      to={`/update-job/${job._id}`}
                    >
                      Edit
                    </Link>
                  </Table.Cell>
                </Table.Row>
              ))}
            </Table.Body>
          </Table>

          {showMore && (
            <button
              onClick={handleShowMore}
              className="w-full text-teal-500 self-center text-sm py-2 hover:underline"
            >
              Show more
            </button>
          )}
        </>
      ) : (
        <p className="text-gray-500">You have no jobs yet!</p>
      )}

      {/* Delete Confirmation Modal */}
      <Modal show={showModal} onClose={() => setShowModal(false)} popup size="md">
        <Modal.Header />
        <Modal.Body>
          <div className="text-center">
            <HiOutlineExclamationCircle className="h-14 w-14 text-gray-400 mb-4" />
            <h3 className="mb-5 text-lg text-gray-500">
              Are you sure you want to delete this job?
            </h3>
            <div className="flex justify-center gap-4">
              <Button color="failure" onClick={handleDeleteJob}>
                Yes, I'm sure
              </Button>
              <Button color="gray" onClick={() => setShowModal(false)}>
                No, cancel
              </Button>
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
}
