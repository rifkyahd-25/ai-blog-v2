import React from "react";
import { Link } from "react-router-dom";

export default function Homecard({ post }) {
  return (
    <Link to={`/post/${post.slug}`}>
      <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 shadow hover:shadow-md transition-all duration-300 overflow-hidden">
        {/* Image */}
        <div className="relative h-40 sm:h-48 overflow-hidden">
          <img
            src={`${post.image}?f_auto&q_auto`}
            alt="post cover"
            className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />
        </div>

        {/* Content */}
        <div className="p-4 flex flex-col justify-between h-full">
          <h4 className="text-lg font-semibold text-gray-900 dark:text-white leading-snug">
            {post.title}
          </h4>

          {/* Author & Date */}
          <div className="flex items-center justify-between mt-4 text-sm text-gray-500 dark:text-gray-400">
            <div className="flex items-center space-x-2">
              <img
                src={post.author?.profilePicture}
                alt={post.author?.username}
                className="w-8 h-8 rounded-full border border-gray-300 dark:border-gray-700"
              />
              <span>{post.author?.username}</span>
            </div>
            <span>
              {new Date(post.createdAt).toLocaleDateString("en-US", {
                month: "short",
                day: "numeric",
              })}
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}
