import { Footer } from 'flowbite-react';
import { Link } from 'react-router-dom';
import { BsFacebook, BsInstagram, BsTwitter, BsGithub, BsDribbble } from 'react-icons/bs';

export default function FooterCom() {
  return (
    <Footer container className="bg-[#0D3B66] text-white py-10">
      <div className="w-full max-w-7xl mx-auto">
        
        {/* Top Section */}
        <div className="grid w-full justify-between sm:flex md:grid-cols-1 items-center">
          {/* Logo */}
          <div className="mt-5">
            <Link
              to="/"
              className="flex items-center gap-2 text-lg sm:text-2xl font-semibold text-white"
            >
              <span className="px-4 py-1.5 bg-yellow-500 rounded-xl text-[#0D3B66] text-base sm:text-lg shadow-md">
                RRR
              </span>
              <span className="text-base sm:text-xl">Blog</span>
            </Link>
          </div>

          {/* Links */}
          <div className="grid grid-cols-2 gap-8 mt-6 sm:grid-cols-3 sm:gap-12">
            <div>
              <Footer.Title title="About" className="text-white uppercase tracking-wide" />
              <Footer.LinkGroup col>
                <Footer.Link
                  href="/about"
                  className="hover:text-yellow-400 transition-colors"
                >
                  Rifky Blog
                </Footer.Link>
              </Footer.LinkGroup>
            </div>

            <div>
              <Footer.Title title="Legal" className="text-white uppercase tracking-wide" />
              <Footer.LinkGroup col>
                <Footer.Link
                  href="/privacy"
                  className="hover:text-yellow-400 transition-colors"
                >
                  Privacy Policy
                </Footer.Link>
                <Footer.Link
                  href="/termsandcondition"
                  className="hover:text-yellow-400 transition-colors"
                >
                  Terms &amp; Conditions
                </Footer.Link>
              </Footer.LinkGroup>
            </div>
          </div>
        </div>

        <Footer.Divider className="my-6 border-gray-500" />

        {/* Bottom Section */}
        <div className="w-full sm:flex sm:items-center sm:justify-between">
          <Footer.Copyright
            href="#"
            by="Rifky's Blog"
            year={new Date().getFullYear()}
            className="text-gray-300"
          />
          <div className="flex gap-6 sm:mt-0 mt-4 sm:justify-center">
            <Footer.Icon href="#" icon={BsFacebook} className="hover:text-yellow-400" />
            <Footer.Icon href="#" icon={BsInstagram} className="hover:text-yellow-400" />
            <Footer.Icon href="#" icon={BsTwitter} className="hover:text-yellow-400" />
            <Footer.Icon href="#" icon={BsGithub} className="hover:text-yellow-400" />
            <Footer.Icon href="#" icon={BsDribbble} className="hover:text-yellow-400" />
          </div>
        </div>
      </div>
    </Footer>
  );
}
