const PostSkeleton = () => {
    return (
      <div className="w-full max-w-4xl mx-auto p-3 animate-pulse">
        {/* Title */}
        <div className="h-10 bg-gray-300 dark:bg-gray-700 rounded-md mb-5 w-3/4 mx-auto"></div>
        
        {/* Category button */}
        <div className="h-6 w-32 bg-gray-300 dark:bg-gray-700 rounded-full mb-5 mx-auto"></div>
        
        {/* Image */}
        <div className="h-64 w-full bg-gray-300 dark:bg-gray-700 rounded-lg mb-5"></div>
        
        {/* Meta info */}
        <div className="flex justify-between mb-5 text-xs">
          <div className="h-4 w-24 bg-gray-300 dark:bg-gray-700 rounded"></div>
          <div className="h-4 w-20 bg-gray-300 dark:bg-gray-700 rounded"></div>
        </div>
        
        {/* Paragraphs */}
        <div className="space-y-3">
          <div className="h-4 w-full bg-gray-300 dark:bg-gray-700 rounded"></div>
          <div className="h-4 w-full bg-gray-300 dark:bg-gray-700 rounded"></div>
          <div className="h-4 w-5/6 bg-gray-300 dark:bg-gray-700 rounded"></div>
          <div className="h-4 w-3/4 bg-gray-300 dark:bg-gray-700 rounded"></div>
        </div>
  
        {/* Recent posts */}
        <div className="mt-10 space-y-3">
          <div className="h-6 w-32 bg-gray-300 dark:bg-gray-700 rounded mb-3"></div>
          <div className="flex flex-wrap gap-5">
            <div className="h-48 w-72 bg-gray-300 dark:bg-gray-700 rounded-lg"></div>
            <div className="h-48 w-72 bg-gray-300 dark:bg-gray-700 rounded-lg"></div>
            <div className="h-48 w-72 bg-gray-300 dark:bg-gray-700 rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  };
  
  export default PostSkeleton;
  