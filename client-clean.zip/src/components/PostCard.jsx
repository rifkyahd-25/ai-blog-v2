import { Link } from 'react-router-dom';

export default function PostCard({ post }) {
  return (
    <div className="group relative w-full sm:w-[430px] bg-white rounded-xl overflow-hidden shadow-lg border border-gray-200 hover:shadow-xl transition-all duration-300">
      {/* Blog Cover Image */}
      <Link to={`/post/${post.slug}`} className="block overflow-hidden">
        <img
          src={post.image}
          alt={post.title}
          className="w-full h-[230px] object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </Link>

      {/* Blog Content */}
      <div className="p-5">
        <span className="text-sm font-semibold text-[#0D3B66] uppercase tracking-wide">
          {post.category}
        </span>
        <h3 className="mt-2 text-lg font-bold text-gray-900 leading-snug transition-colors duration-300 group-hover:text-[#0D3B66] line-clamp-2">
          {post.title}
        </h3>
      </div>

      {/* Read More Button */}
      <div className="p-5 pt-0">
        <Link
          to={`/post/${post.slug}`}
          className="inline-block px-4 py-2 text-sm font-semibold text-white bg-yellow-500 rounded-lg hover:bg-yellow-400 transition-all duration-300 shadow-md"
        >
          Read Article →
        </Link>
      </div>
    </div>
  );
}
