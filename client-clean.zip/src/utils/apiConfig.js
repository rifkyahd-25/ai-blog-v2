// Local-only setup: the client always talks to your local Express server
// (matches `app.listen(3000)` in the backend's api/index.js).
// Override with VITE_API_BASE_URL in your .env if you ever point this at a
// hosted backend instead — nothing else in the app needs to change.
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:3000";
