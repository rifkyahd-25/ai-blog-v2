import { useState, useEffect, useRef } from "react";
import EditorJS from "@editorjs/editorjs";
import Header from "@editorjs/header";
import List from "@editorjs/list";
import Quote from "@editorjs/quote";
import ImageTool from "@editorjs/image";
import Paragraph from "@editorjs/paragraph";
import { Alert, Button, FileInput, TextInput } from "flowbite-react";
import { CircularProgressbar } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";
import { useNavigate } from "react-router-dom";
import Table from "@editorjs/table";
import Marker from "@editorjs/marker";
import Embed from "@editorjs/embed";
import LinkTool from "@coolbytes/editorjs-link";
import { useSelector } from "react-redux"; // Assuming you're using Redux for auth
import { API_BASE_URL } from "../utils/apiConfig";

export default function CreatePost() {
  const editorRef = useRef(null);
  const [file, setFile] = useState(null);
  const [imageUploadProgress, setImageUploadProgress] = useState(null);
  const [imageUploadError, setImageUploadError] = useState(null);
  const [formData, setFormData] = useState({});
  const [imageFileUrl, setImageFileUrl] = useState(null);
  const [publishError, setPublishError] = useState(null);
  const navigate = useNavigate();
  
  // Get token from your auth state (adjust based on your auth setup)
  const { token } = useSelector((state) => state.auth) || {};

  // Upload thumbnail
  const handleUploadImage = async () => {
    if (!file) return;
    const data = new FormData();
    data.append("file", file);
    data.append("upload_preset", import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET);
    data.append("cloud_name", import.meta.env.VITE_CLOUDINARY_CLOUD_NAME);

    try {
      const res = await fetch(
        `https://api.cloudinary.com/v1_1/${
          import.meta.env.VITE_CLOUDINARY_CLOUD_NAME
        }/image/upload`,
        { method: "POST", body: data }
      );
      if (!res.ok) throw new Error("Upload failed");
      const uploaded = await res.json();
      const webpUrl = uploaded.url.replace("/upload/", "/upload/f_webp/");
      setImageFileUrl(webpUrl);
      setFormData((prev) => ({ ...prev, image: webpUrl }));
    } catch {
      setImageUploadError("Image upload failed.");
    }
  };

  // Editor.js init
  useEffect(() => {
    let isMounted = true;

    const initEditor = async () => {
      if (!editorRef.current && isMounted) {
        editorRef.current = new EditorJS({
          holder: "editorjs",
          tools: {
            header: {
              class: Header,
              inlineToolbar: ["link"],
            },
            list: { class: List, inlineToolbar: ["link"] },
            quote: Quote,
            paragraph: {
              class: Paragraph,
              inlineToolbar: ["link"],
            },
            embed: Embed,
            marker: Marker,
            table: Table,
            link: {
              class: LinkTool,
              config: {
                shortcut: "CMD+L",
                placeholder: "Enter URL",
                targets: ["_self", "_blank"],
                defaultTarget: "_blank",
              },
            },
            image: {
              class: ImageTool,
              config: {
                uploader: {
                  uploadByFile: async (file) => {
                    const data = new FormData();
                    data.append("file", file);
                    data.append(
                      "upload_preset",
                      import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET
                    );
                    data.append(
                      "cloud_name",
                      import.meta.env.VITE_CLOUDINARY_CLOUD_NAME
                    );
                    try {
                      const res = await fetch(
                        `https://api.cloudinary.com/v1_1/${
                          import.meta.env.VITE_CLOUDINARY_CLOUD_NAME
                        }/image/upload`,
                        { method: "POST", body: data }
                      );
                      const result = await res.json();
                      const webpUrl = result.url.replace(
                        "/upload/",
                        "/upload/f_webp/"
                      );
                      return {
                        success: 1,
                        file: { url: webpUrl },
                      };
                    } catch {
                      return { success: 0 };
                    }
                  },
                },
              },
            },
          },
          placeholder: "Write something amazing...",
          // Only load data if it exists and has the expected structure
          data: formData.content && Object.keys(formData.content).length > 0 
            ? formData.content 
            : undefined,
          onReady: () => {
            console.log("Editor.js is ready to work!");
          },
          onChange: async () => {
            if (editorRef.current) {
              const content = await editorRef.current.save();
              setFormData((prev) => ({ ...prev, content }));
            }
          },
        });
      }
    };

    initEditor();

    return () => {
      isMounted = false;
      if (editorRef.current && editorRef.current.destroy) {
        editorRef.current.destroy();
        editorRef.current = null;
      }
    };
  }, [formData.content]); // Fixed typo here

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!editorRef.current) return;

    const savedData = await editorRef.current.save();

    // Validate that savedData has the expected structure
    if (!savedData || !savedData.blocks) {
      setPublishError("Invalid content format");
      return;
    }

    const payload = {
      ...formData,
      content: savedData,
    };

    try {
      const res = await fetch(`${API_BASE_URL}/api/post/create`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      const data = await res.json();
      if (!res.ok) {
        setPublishError(data.message || "Post creation failed");
        return;
      }
      navigate(`/post/${data.slug}`);
    } catch (error) {
      console.error("Submit error:", error);
      setPublishError("Post creation failed");
    }
  };

  return (
    <div className="p-3 max-w-3xl mx-auto min-h-screen">
      <h1 className="text-center text-3xl my-7 font-semibold">Create a post</h1>
      <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
        <div className="flex flex-col gap-4 sm:flex-row justify-between">
          <TextInput
            type="text"
            placeholder="Title"
            required
            id="title"
            className="flex-1"
            onChange={(e) =>
              setFormData({ ...formData, title: e.target.value })
            }
          />
          <select
            onChange={(e) =>
              setFormData({ ...formData, category: e.target.value })
            }
          >
            <option value="uncategorized">Select a category</option>
            <option value="fashion-style">Fashion & Style</option>
            <option value="beauty-skincare">Beauty & Skincare</option>
            <option value="lifestyle-wellness">Lifestyle & Wellness</option>
            <option value="home-decor-living">Home Decor & Living</option>
            <option value="sustainable-living">Sustainable Living</option>
            <option value="seasonal-holiday">Holiday & Seasonal</option>
            <option value="shopping-guides">Shopping Guides</option>
            <option value="style-tips">Style Tips & How-Tos</option>
            <option value="influencer-community">Influencer & Community</option>
            <option value="seo-longform">SEO-Friendly & Longform</option>
          </select>
        </div>

        {/* Post thumbnail */}
        <div className="flex gap-4 items-center justify-between border-4 border-teal-500 border-dotted p-3">
          <FileInput
            type="file"
            accept="image/*"
            onChange={(e) => setFile(e.target.files[0])}
          />
          <Button
            type="button"
            gradientDuoTone="purpleToBlue"
            size="sm"
            outline
            onClick={handleUploadImage}
            disabled={imageUploadProgress}
          >
            {imageUploadProgress ? (
              <div className="w-16 h-16">
                <CircularProgressbar
                  value={imageUploadProgress}
                  text={`${imageUploadProgress || 0}%`}
                />
              </div>
            ) : (
              "Upload Image"
            )}
          </Button>
        </div>

        {imageUploadError && <Alert color="failure">{imageUploadError}</Alert>}
        {formData.image && (
          <img
            src={formData.image}
            alt="upload"
            className="w-full h-72 object-cover"
          />
        )}

        {/* Editor.js */}
        <div
          id="editorjs"
          className="min-h-[300px] border border-gray-300 rounded-lg p-4"
        />

        <Button type="submit" gradientDuoTone="purpleToPink">
          Publish
        </Button>

        {publishError && (
          <Alert className="mt-5" color="failure">
            {publishError}
          </Alert>
        )}
      </form>
    </div>
  );
}