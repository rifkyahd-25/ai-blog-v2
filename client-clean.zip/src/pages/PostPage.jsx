import { Button, Spinner } from "flowbite-react";
import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

import CommentSection from "../components/CommentSection";
import PostCard from "../components/PostCard";
import ShareButtons from "../components/ShareButtons";
import DOMPurify from "dompurify"; // Import DOMPurify for sanitizing content
import { API_BASE_URL } from "../utils/apiConfig";

export default function Postpage() {
  const { postSlug } = useParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [post, setPost] = useState(null);
  const [recentPosts, setRecentPosts] = useState(null);

  // Fetch post by slug
  useEffect(() => {
    const fetchPost = async () => {
      try {
        setLoading(true);
        const res = await fetch(`${API_BASE_URL}/api/post/getposts?slug=${postSlug}`);
        const data = await res.json();
        if (!res.ok) {
          setError(true);
          setLoading(false);
          return;
        }
        setPost(data.posts[0]);
        console.log("Fetched Post Data: ", data.posts[0]);
        setLoading(false);
        setError(false);
      } catch (error) {
        setError(true);
        setLoading(false);
      }
    };
    fetchPost();
  }, [postSlug]);

  // Fetch recent posts
  useEffect(() => {
    const fetchRecentPosts = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/api/post/getall?limit=3`);
        const data = await res.json();
        if (res.ok) setRecentPosts(data.posts);
      } catch (error) {
        console.log(error.message);
      }
    };
    fetchRecentPosts();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Spinner size="xl" />
      </div>
    );
  }

  // ✅ Render Editor.js blocks
  const renderEditorJsContent = (blocks) => {
    if (!blocks || !Array.isArray(blocks)) return "<p>No content available</p>";
  
    return blocks
      .map((block) => {
        switch (block.type) {
          case "paragraph":
            return `<p>${block.data.text}</p>`;
          case "header":
            return `<h${block.data.level}>${block.data.text}</h${block.data.level}>`;
            case "list":
              // If block has 'content' but no 'items', create items from 'content' directly
              const tag = block.data.style === "ordered" ? "ol" : "ul";
              const items = block.data.items && Array.isArray(block.data.items)
                ? block.data.items
                    .map((item) => {
                      // Check if item is a string or has 'content' and render it
                      if (typeof item === "string") {
                        return `<li>${item.trim()}</li>`;
                      } else if (typeof item === "object" && item.content) {
                        return `<li>${item.content.trim()}</li>`;
                      }
                      return "";
                    })
                    .join("")
                : `<li>${block.data.content.trim()}</li>`; // Fallback for cases without items, using content directly
              return `<${tag}>${items}</${tag}>`;
          case "quote":
            return `<blockquote>${block.data.text}</blockquote>`;
          case "image":
            return `<img src="${block.data.file.url}" alt="${block.data.caption || ''}" />`;
          case "code":
            return `<pre><code>${block.data.code}</code></pre>`;
          default:
            return "";
        }
      })
      .join("");
  };

  return (
    <main className="p-3 flex flex-col max-w-6xl mx-auto min-h-screen">
      <h1 className="text-3xl mt-10 p-3 text-center font-serif max-w-2xl mx-auto lg:text-4xl">
        {post && post.title}
      </h1>

      <ShareButtons url={window.location.href} title={post.title} />

      <Link
        to={`/search?category=${post.category}`}
        className="self-center mt-5"
      >
        <Button>{post && post.category}</Button>
      </Link>

      <img
        src={post && post.image}
        alt={post && post.title}
        className="mt-10 p-3 max-h-[600px] w-full object-cover"
        loading="lazy"
      />

      <div className="flex justify-between p-3 border-b border-slate-500 mx-auto w-full max-w-2xl text-xs">
        <span>{post && new Date(post.createdAt).toLocaleTimeString()}</span>
        <span className="italic">{post && (post.content?.blocks?.length || 1)} mins read</span>
      </div>

      {/* 📝 Render Editor.js content */}
      <div
        className="p-3 max-w-4xl mx-auto w-full post-content"
        dangerouslySetInnerHTML={{
          __html: DOMPurify.sanitize(renderEditorJsContent(post.content.blocks))
        }}
      />

      <div className="max-w-4xl mx-auto w-full">
        {/* <CallToAction /> */}
      </div>

      <CommentSection postId={post._id} />

      <div className="flex flex-col justify-center items-center mb-5">
        <h1 className="text-xl mt-5">Recent articles</h1>
        <div className="flex flex-wrap gap-5 mt-5 justify-center">
          {recentPosts &&
            recentPosts.map((post) => <PostCard key={post._id} post={post} />)}
        </div>
      </div>
    </main>
  );
}
