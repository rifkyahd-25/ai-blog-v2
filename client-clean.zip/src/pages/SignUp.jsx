import React, { useState, useCallback, useMemo } from "react";
import { Alert, Button, Label, TextInput, Spinner } from "flowbite-react";
import { Link, useNavigate } from "react-router-dom";
import OAuth from "../components/OAuth";
import { API_BASE_URL } from "../utils/apiConfig";

// Simple skeleton loader for form
const FormSkeleton = () => (
  <div className="animate-pulse flex flex-col gap-4">
    <div className="h-6 bg-gray-300 dark:bg-gray-700 rounded w-32"></div>
    <div className="h-10 bg-gray-200 dark:bg-gray-600 rounded"></div>
    <div className="h-6 bg-gray-300 dark:bg-gray-700 rounded w-28"></div>
    <div className="h-10 bg-gray-200 dark:bg-gray-600 rounded"></div>
    <div className="h-6 bg-gray-300 dark:bg-gray-700 rounded w-28"></div>
    <div className="h-10 bg-gray-200 dark:bg-gray-600 rounded"></div>
    <div className="h-10 bg-gray-200 dark:bg-gray-600 rounded"></div>
  </div>
);

export default function SignUp() {
  const [formData, setFormData] = useState({});
  const [errorMessage, setErrorMessage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [initializing, setInitializing] = useState(false);
  const navigate = useNavigate();

  const handleChange = useCallback((e) => {
    setFormData((prev) => ({ ...prev, [e.target.id]: e.target.value.trim() }));
  }, []);

  const isFormValid = useMemo(
    () => formData.username && formData.email && formData.password,
    [formData]
  );

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isFormValid) {
      return setErrorMessage("Please fill out all fields.");
    }

    try {
      setLoading(true);
      setErrorMessage(null);
      const res = await fetch(`${API_BASE_URL}/api/auth/signup`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData),
        }
      );
      const data = await res.json();
      if (data.success === false) {
        setErrorMessage(data.message);
        setLoading(false);
        return;
      }
      navigate("/sign-in");
    } catch (error) {
      setErrorMessage(error.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen mt-20">
      <div className="flex p-3 max-w-3xl mx-auto flex-col md:flex-row md:items-center gap-5">
        {/* Left side */}
        <div className="flex-1">
          <Link
            to="/"
            className="font-bold text-light-text dark:text-dark-text text-4xl"
          >
            <span className="px-2 py-1 bg-gradient-to-r from-light-primary to-light-link rounded-lg text-white shadow-md">
              RRR
            </span>
            Blog
          </Link>
          <p className="text-sm mt-5 text-gray-600 dark:text-gray-300">
            Join RRR_Blog today! Sign up with your email and password, or use
            Google for quick access.
          </p>
        </div>

        {/* Right side */}
        <div className="flex-1 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
          {initializing ? (
            <FormSkeleton />
          ) : (
            <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
              <div>
                <Label value="Username" />
                <TextInput
                  type="text"
                  placeholder="Your username"
                  id="username"
                  onChange={handleChange}
                />
              </div>
              <div>
                <Label value="Email" />
                <TextInput
                  type="email"
                  placeholder="Enter your email"
                  id="email"
                  onChange={handleChange}
                />
              </div>
              <div>
                <Label value="Password" />
                <TextInput
                  type="password"
                  placeholder="Enter your password"
                  id="password"
                  onChange={handleChange}
                />
              </div>
              <Button
                gradientDuoTone="cyanToBlue"
                type="submit"
                disabled={loading || !isFormValid}
              >
                {loading ? (
                  <>
                    <Spinner size="sm" />
                    <span className="pl-3">Signing up...</span>
                  </>
                ) : (
                  "Sign Up"
                )}
              </Button>
              <OAuth />
            </form>
          )}

          <div className="flex gap-2 text-sm mt-5 text-gray-600 dark:text-gray-300">
            <span>Have an account?</span>
            <Link to="/sign-in" className="text-blue-500 hover:underline">
              Sign In
            </Link>
          </div>

          {errorMessage && (
            <Alert className="mt-5" color="failure">
              {errorMessage}
            </Alert>
          )}
        </div>
      </div>
    </div>
  );
}
