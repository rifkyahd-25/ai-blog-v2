import React from 'react'

export default function PrivacyPolicy() {
  return (
    <div className="max-w-4xl mx-auto p-6 text-gray-800">
      <h1 className="text-3xl font-bold mb-4">Privacy Policy</h1>
      <p className="text-sm text-gray-500 mb-6">
        <strong>Effective Date:</strong> August 15, 2025 <br />
        <strong>Website:</strong>{' '}
        <a href="https://rrr-blog-1.onrender.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">
          RRR Blog
        </a>
      </p>

      <section className="mb-6">
        <h2 className="text-xl font-semibold mb-2">1. Information We Collect</h2>
        <p>We may collect the following types of information:</p>
        <ul className="list-disc list-inside mt-2">
          <li>
            <strong>Account Information:</strong> Name, Email, and Password (stored securely) when you sign up or sign in.
          </li>
          <li>
            <strong>Personal Information:</strong> Information voluntarily provided via contact forms, comments, or newsletter subscriptions.
          </li>
          <li>
            <strong>Non-Personal Information:</strong> Browser type, IP address, pages visited, time spent, referring site, and other usage analytics.
          </li>
        </ul>
        <p className="mt-2">
          We use cookies, analytics tools (like Google Analytics), and third-party authentication services (e.g., Google OAuth) to improve user experience and track visitor behavior.
        </p>
      </section>

      <section className="mb-6">
        <h2 className="text-xl font-semibold mb-2">2. How We Use Your Information</h2>
        <ul className="list-disc list-inside">
          <li>To manage your account and authenticate users</li>
          <li>To respond to inquiries or feedback</li>
          <li>To send newsletters or updates (only if you subscribe)</li>
          <li>To analyze website usage and improve our content and services</li>
        </ul>
        <p className="mt-2">
          <strong>We do not sell or share your personal data</strong> with third parties for marketing purposes.
        </p>
      </section>

      <section className="mb-6">
        <h2 className="text-xl font-semibold mb-2">3. User Content</h2>
        <p>
          Any comments, posts, or messages you submit may be publicly visible. We moderate content to maintain a safe and informative environment. You are responsible for the content you share.
        </p>
      </section>

      <section className="mb-6">
        <h2 className="text-xl font-semibold mb-2">4. Third-Party Services</h2>
        <p>
          RRR Blog may use third-party services such as analytics, commenting plugins, or authentication providers. These services may collect and process your data according to their own privacy policies.
        </p>
      </section>

      <section className="mb-6">
        <h2 className="text-xl font-semibold mb-2">5. Cookies</h2>
        <p>
          Cookies are small files stored on your device to enhance user experience. You can disable cookies in your browser settings, but some site features may not function correctly.
        </p>
      </section>

      <section className="mb-6">
        <h2 className="text-xl font-semibold mb-2">6. Your Rights</h2>
        <p>You have the right to:</p>
        <ul className="list-disc list-inside mt-2">
          <li>Access or request a copy of the personal data we hold about you</li>
          <li>Request correction or deletion of your personal information</li>
          <li>Opt-out of newsletters or marketing communications at any time</li>
        </ul>
      </section>

      <section className="mb-6">
        <h2 className="text-xl font-semibold mb-2">7. Children’s Privacy</h2>
        <p>
          RRR Blog is not intended for children under 13 years old. We do not knowingly collect personal information from children.
        </p>
      </section>

      <section className="mb-6">
        <h2 className="text-xl font-semibold mb-2">8. Changes to This Privacy Policy</h2>
        <p>
          We may update this Privacy Policy from time to time. Changes will be reflected on this page with a revised effective date.
        </p>
      </section>

      <section className="mb-6">
        <h2 className="text-xl font-semibold mb-2">9. Contact Us</h2>
        <p>
          For questions or concerns about this Privacy Policy, please contact us:
        </p>
        <p className="mt-2">
          📧 Email: <a href="mailto:rrrblog1@gmail.com" className="text-blue-600 underline">rrrblog1@gmail.com</a>
        </p>
      </section>
    </div>
  );
}
