import { Spinner } from "flowbite-react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Homecard from "../components/Homecard";
import img from "../assets/img.jpg";
import { FaBriefcase, FaMapMarkerAlt, FaCalendarAlt } from "react-icons/fa";
import { API_BASE_URL } from "../utils/apiConfig";

// Skeleton Components
const CardSkeleton = () => (
  <div className="bg-gray-200 dark:bg-gray-700 rounded-lg shadow p-6 animate-pulse">
    {/* Image Placeholder */}
    <div className="h-32 bg-gray-300 dark:bg-gray-600 rounded mb-4"></div>

    {/* Title Placeholder */}
    <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded w-3/4 mb-2"></div>

    {/* Text Lines */}
    <div className="h-3 bg-gray-300 dark:bg-gray-600 rounded w-full mb-1"></div>
    <div className="h-3 bg-gray-300 dark:bg-gray-600 rounded w-5/6"></div>
  </div>
);

const JobSkeleton = () => (
  <div className="bg-gray-200 dark:bg-gray-700 rounded-lg shadow p-6 animate-pulse">
    {/* Icon & Title Row */}
    <div className="flex items-center gap-4 mb-4">
      <div className="w-10 h-10 bg-gray-300 dark:bg-gray-600 rounded-full"></div>
      <div className="flex-1">
        <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded w-2/3 mb-1"></div>
        <div className="h-3 bg-gray-300 dark:bg-gray-600 rounded w-1/2"></div>
      </div>
    </div>

    {/* Info Lines */}
    <div className="h-3 bg-gray-300 dark:bg-gray-600 rounded w-3/4 mb-2"></div>
    <div className="h-3 bg-gray-300 dark:bg-gray-600 rounded w-1/2 mb-4"></div>

    {/* Button Placeholder */}
    <div className="h-8 bg-gray-300 dark:bg-gray-600 rounded"></div>
  </div>
);

export default function Home() {
  const [post, setPost] = useState(null);
  const [recentPosts, setRecentPosts] = useState(null);
  const [recentJobs, setRecentJobs] = useState(null);
  const [loadingPosts, setLoadingPosts] = useState(true);
  const [loadingJobs, setLoadingJobs] = useState(true);
  const [error, setError] = useState(false);

  // Fetch Recent Posts
  useEffect(() => {
    const fetchPosts = async () => {
      try {
        setLoadingPosts(true);
        const [postRes, recentPostsRes] = await Promise.all([
          fetch(`${API_BASE_URL}/api/post/getall?limit=1&order=desc`),
          fetch(`${API_BASE_URL}/api/post/getall?limit=6`),
        ]);
        const postData = await postRes.json();
        const recentPostsData = await recentPostsRes.json();

        if (!postRes.ok || !recentPostsRes.ok) throw new Error();

        setPost(postData.posts[0]);
        setRecentPosts(recentPostsData.posts);
        setLoadingPosts(false);
      } catch {
        setError(true);
        setLoadingPosts(false);
      }
    };
    fetchPosts();
  }, []);

  // Fetch Recent Jobs
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        setLoadingJobs(true);
        const res = await fetch(`${API_BASE_URL}/api/job/getall?limit=6`);
        const data = await res.json();
        if (!res.ok) throw new Error();
        setRecentJobs(data.jobs);
        setLoadingJobs(false);
      } catch {
        setError(true);
        setLoadingJobs(false);
      }
    };
    fetchJobs();
  }, []);

  return (
    <>
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-800 to-blue-600 text-white py-14">
        <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex-1">
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">
              Your Future Starts Here
            </h1>
            <p className="mt-4 text-gray-200 max-w-lg">
              Find the latest jobs and news to help you succeed in Sri Lanka.
            </p>
            <div className="mt-6 flex bg-white rounded-lg overflow-hidden shadow-lg max-w-md">
              <select className="p-3 text-gray-700 border-none focus:ring-0 outline-none">
                <option>Jobs</option>
                <option>News</option>
              </select>
              <input
                type="text"
                placeholder="Search..."
                className="flex-1 p-3 outline-none"
              />
              <button className="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-3 font-medium">
                Search
              </button>
            </div>
          </div>
          <div className="flex-1 flex justify-center">
            <img src={img} alt="Hero" className="max-h-80 rounded-lg shadow-lg" />
          </div>
        </div>
      </div>

      {/* Popular Posts */}
      <section className="max-w-6xl mx-auto px-4 py-12">
        <h3 className="text-3xl font-bold text-center mb-2">Popular Posts</h3>
        <p className="text-gray-500 text-center">Ideas, trends, and inspiration for a brighter future</p>
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {loadingPosts
            ? Array(6).fill(0).map((_, i) => <CardSkeleton key={i} />)
            : recentPosts?.map((post) => <Homecard key={post._id} post={post} />)}
        </div>
      </section>

      {/* Recent Jobs */}
      <section className="bg-gray-50 dark:bg-gray-800 py-12">
        <div className="max-w-6xl mx-auto px-4">
          <h3 className="text-3xl font-bold text-center mb-2">Recent Jobs</h3>
          <p className="text-gray-500 text-center">Latest opportunities for you</p>
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {loadingJobs
              ? Array(6).fill(0).map((_, i) => <JobSkeleton key={i} />)
              : recentJobs?.map((job) => (
                  <div key={job._id} className="bg-white dark:bg-gray-900 rounded-lg shadow hover:shadow-lg hover:-translate-y-1 transition p-6 flex flex-col justify-between">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="bg-blue-900 text-white p-3 rounded-full">
                        <FaBriefcase size={20} />
                      </div>
                      <div>
                        <h2 className="text-lg font-semibold">{job.title}</h2>
                        <p className="text-gray-600 dark:text-gray-300">{job.company}</p>
                      </div>
                    </div>
                    <div className="flex gap-4 text-gray-500 text-sm mb-4">
                      <div className="flex items-center gap-1">
                        <FaCalendarAlt /> {new Date(job.createdAt).toLocaleDateString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <FaMapMarkerAlt /> {job.location || "Remote"}
                      </div>
                      <span>{job.type}</span>
                    </div>
                    <Link to={`/jobs/${job._id}`} className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded font-medium text-center">
                      Apply Now
                    </Link>
                  </div>
                ))}
          </div>
        </div>
      </section>
    </>
  );
}
