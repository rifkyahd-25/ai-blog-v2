import { useState, useEffect, useCallback } from "react";
import { TextInput, Select, Button, Spinner } from "flowbite-react";
import { FaBriefcase, FaMapMarkerAlt, FaCalendarAlt } from "react-icons/fa";
import debounce from "lodash.debounce";
import { API_BASE_URL } from "../utils/apiConfig";

// Skeleton component for loading
const JobSkeleton = () => (
  <div className="p-5 bg-gray-200 dark:bg-gray-700 rounded-lg animate-pulse h-48 flex flex-col justify-between">
    <div className="flex gap-4 mb-4">
      <div className="bg-gray-300 dark:bg-gray-600 w-12 h-12 rounded-full" />
      <div className="flex-1 space-y-2">
        <div className="h-4 w-3/4 bg-gray-300 dark:bg-gray-600 rounded" />
        <div className="h-3 w-1/2 bg-gray-300 dark:bg-gray-600 rounded" />
        <div className="h-3 w-1/4 bg-gray-300 dark:bg-gray-600 rounded" />
      </div>
    </div>
    <div className="h-8 w-full bg-gray-300 dark:bg-gray-600 rounded" />
  </div>
);

export default function JobListings() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [category, setCategory] = useState("all");

  // Fetch jobs from API
  const fetchJobs = useCallback(
    async (searchTermValue = searchTerm, categoryValue = category) => {
      setLoading(true);
      try {
        const params = new URLSearchParams();
        if (searchTermValue) params.append("searchTerm", searchTermValue);
        if (categoryValue !== "all") params.append("category", categoryValue);

        const res = await fetch(
          `${API_BASE_URL}/api/job/getall?${params.toString()}`
        );
        const data = await res.json();
        setJobs(data.jobs || []);
      } catch (error) {
        console.error("Failed to fetch jobs", error);
      }
      setLoading(false);
    },
    [searchTerm, category]
  );

  // Debounced search for better performance
  const debouncedFetch = useCallback(debounce(fetchJobs, 500), [fetchJobs]);

  useEffect(() => {
    debouncedFetch();
    return debouncedFetch.cancel;
  }, [searchTerm, category, debouncedFetch]);

  const today = new Date().toDateString();
  const todayJobs = jobs.filter(
    (job) => new Date(job.createdAt).toDateString() === today
  );
  const otherJobs = jobs.filter(
    (job) => new Date(job.createdAt).toDateString() !== today
  );

  const renderJobCard = (job) => (
    <div
      key={job._id}
      className="p-5 bg-white dark:bg-gray-800 rounded-lg shadow hover:shadow-xl transition flex flex-col justify-between"
    >
      <div className="flex items-center gap-4">
        <div className="bg-blue-900 text-white p-3 rounded-full">
          <FaBriefcase size={20} />
        </div>
        <div>
          <h2 className="text-lg font-semibold">{job.title}</h2>
          <p className="text-gray-600 dark:text-gray-300">{job.company}</p>
          <div className="flex flex-wrap gap-4 text-gray-500 dark:text-gray-400 mt-1 text-sm">
            <div className="flex items-center gap-1">
              <FaCalendarAlt /> {new Date(job.createdAt).toLocaleDateString()}
            </div>
            <div className="flex items-center gap-1">
              <FaMapMarkerAlt /> {job.location || "Remote"}
            </div>
            <div>{job.type}</div>
          </div>
        </div>
      </div>
      <Button
        color="yellow"
        onClick={() => window.open(job.applyLink || "#", "_blank")}
        className="mt-4"
      >
        Apply
      </Button>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      {/* Header & Filters */}
      <div className="bg-blue-900 rounded-lg p-10 text-white flex flex-col md:flex-row items-center gap-6 md:gap-10">
        <div className="flex-1">
          <h1 className="text-4xl font-bold mb-2">Jobs</h1>
          <p className="text-lg">
            Latest job opportunities in Sri Lanka for students and job seekers.
          </p>
        </div>
        <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto">
          <Select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="flex-1"
          >
            <option value="all">All Categories</option>
            <option value="Full-time">Full-time</option>
            <option value="Part-time">Part-time</option>
            <option value="Internship">Internship</option>
            <option value="Contract">Contract</option>
          </Select>
          <TextInput
            placeholder="Job title or keyword"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1"
          />
        </div>
      </div>

      {/* Job Listings */}
      <div className="mt-10">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <JobSkeleton key={i} />
            ))}
          </div>
        ) : jobs.length === 0 ? (
          <p className="text-center text-gray-500 dark:text-gray-400">
            No jobs found.
          </p>
        ) : (
          <>
            {/* Today's Jobs */}
            {todayJobs.length > 0 && (
              <div className="mb-10">
                <h2 className="text-2xl font-bold text-blue-900 mb-4">
                  Today Added
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {todayJobs.map((job) => renderJobCard(job))}
                </div>
              </div>
            )}

            {/* All Jobs */}
            <div>
              <h2 className="text-2xl font-bold text-blue-900 mb-4">All Jobs</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {otherJobs.map((job) => renderJobCard(job))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
