import React, { useState, useCallback, useMemo } from "react";
import { Alert, Button, Label, Spinner, TextInput } from "flowbite-react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  signInStart,
  signInSuccess,
  signInFailure,
} from "../redux/user/userSlice";
import OAuth from "../components/OAuth";
import { API_BASE_URL } from "../utils/apiConfig";

// Skeleton loader for form
const FormSkeleton = () => (
  <div className="animate-pulse flex flex-col gap-4">
    <div className="h-6 bg-gray-300 dark:bg-gray-700 rounded w-20"></div>
    <div className="h-10 bg-gray-200 dark:bg-gray-600 rounded"></div>
    <div className="h-6 bg-gray-300 dark:bg-gray-700 rounded w-24"></div>
    <div className="h-10 bg-gray-200 dark:bg-gray-600 rounded"></div>
    <div className="h-10 bg-gray-200 dark:bg-gray-600 rounded"></div>
  </div>
);

export default function Signin() {
  const [formData, setFormData] = useState({});
  const [initializing, setInitializing] = useState(false); // Simulated initial loading state
  const { loading, error: errorMessage } = useSelector((state) => state.user);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleChange = useCallback((e) => {
    setFormData((prev) => ({ ...prev, [e.target.id]: e.target.value.trim() }));
  }, []);

  const isFormValid = useMemo(
    () => formData.email && formData.password,
    [formData]
  );

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isFormValid) {
      return dispatch(signInFailure("Please fill all the fields"));
    }
    try {
      dispatch(signInStart());
      const res = await fetch(`${API_BASE_URL}/api/auth/signin`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData),
        }
      );
      const data = await res.json();
      if (data.success === false) {
        return dispatch(signInFailure(data.message));
      }
      dispatch(signInSuccess(data));
      navigate("/");
    } catch (error) {
      dispatch(signInFailure(error.message || "Something went wrong"));
    }
  };

  return (
    <div className="min-h-screen mt-20">
      <div className="flex p-3 max-w-3xl mx-auto flex-col md:flex-row md:items-center gap-5">
        {/* Left Section */}
        <div className="flex-1">
          <Link
            to="/"
            className="font-bold text-light-text dark:text-dark-text text-4xl"
          >
            <span className="px-2 py-1 bg-gradient-to-r from-light-primary to-light-link rounded-lg text-white shadow-md">
              RRR
            </span>
            Blog
          </Link>
          <p className="text-sm mt-5 text-gray-600 dark:text-gray-300">
            Sign in to RRR_Blog using your email and password, or quickly
            connect with Google.
          </p>
        </div>

        {/* Right Section */}
        <div className="flex-1 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
          {initializing ? (
            <FormSkeleton />
          ) : (
            <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
              <div>
                <Label value="Email" />
                <TextInput
                  id="email"
                  type="email"
                  placeholder="Your email"
                  onChange={handleChange}
                />
              </div>
              <div>
                <Label value="Password" />
                <TextInput
                  id="password"
                  type="password"
                  placeholder="***************"
                  onChange={handleChange}
                />
              </div>
              <Button
                gradientDuoTone="cyanToBlue"
                type="submit"
                disabled={loading || !isFormValid}
              >
                {loading ? (
                  <>
                    <Spinner size="sm" />
                    <span className="pl-3">Signing in...</span>
                  </>
                ) : (
                  "Sign In"
                )}
              </Button>
              <OAuth />
            </form>
          )}

          <div className="flex gap-2 text-sm mt-5 text-gray-600 dark:text-gray-300">
            <span>Don't have an account?</span>
            <Link to="/sign-up" className="text-blue-500 hover:underline">
              Sign up
            </Link>
          </div>

          {errorMessage && (
            <Alert className="mt-5" color="failure">
              {errorMessage}
            </Alert>
          )}
        </div>
      </div>
    </div>
  );
}
