import { Alert, Button, FileInput, Select, TextInput } from "flowbite-react";
import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import { CircularProgressbar } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";

// Editor.js & tools
import EditorJS from "@editorjs/editorjs";
import Header from "@editorjs/header";
import List from "@editorjs/list";
import Quote from "@editorjs/quote";
import ImageTool from "@editorjs/image";
import Paragraph from "@editorjs/paragraph";
import Table from "@editorjs/table";
import Marker from "@editorjs/marker";
import Embed from "@editorjs/embed";
import LinkTool from '@coolbytes/editorjs-link';
import { API_BASE_URL } from "../utils/apiConfig";

export default function UpdatePost() {
  const [file, setFile] = useState(null);
  const [imageUploadProgress, setImageUploadProgress] = useState(null);
  const [imageUploadError, setImageUploadError] = useState(null);
  const [formData, setFormData] = useState({});
  const [publishError, setPublishError] = useState(null);
  const [imageFileUrl, setImageFileUrl] = useState(null);
  const editorRef = useRef(null);
  const isEditorReady = useRef(false);
  const { postId } = useParams();
  const { currentUser } = useSelector((state) => state.user);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchPost = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/api/post/getposts?postId=${postId}`);
        const data = await res.json();
        if (!res.ok) {
          setPublishError(data.message);
          return;
        }
        setFormData(data.posts[0]);
      } catch (error) {
        setPublishError("Error fetching post data");
      }
    };

    fetchPost();
  }, [postId]);

  useEffect(() => {
    if (formData.content && !isEditorReady.current) {
      isEditorReady.current = true;
      editorRef.current = new EditorJS({
        holder: "editorjs",
        data: formData.content,
        tools: {
          header: Header,
          list: List,
          quote: Quote,
          paragraph: { class: Paragraph, inlineToolbar: ['link'] },
          table: Table,
          marker: Marker,
          embed: Embed,
          link: {
            class: LinkTool,
            config: {
              shortcut: 'CMD+L',
              placeholder: 'Enter URL',
              targets: ['_blank'],
              defaultTarget: '_blank',
            },
          },
          image: {
            class: ImageTool,
            config: {
              uploader: {
                uploadByFile: async (file) => {
                  const data = new FormData();
                  data.append("file", file);
                  data.append("upload_preset", import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET);
                  data.append("cloud_name", import.meta.env.VITE_CLOUDINARY_CLOUD_NAME);
                  try {
                    const res = await fetch(
                      `https://api.cloudinary.com/v1_1/${import.meta.env.VITE_CLOUDINARY_CLOUD_NAME}/image/upload`,
                      { method: "POST", body: data }
                    );
                    const result = await res.json();
                    return { success: 1, file: { url: result.url } };
                  } catch {
                    return { success: 0 };
                  }
                },
              },
            },
          },
        },
        placeholder: "Edit your post content...",
      });
    }

    return () => {
      if (editorRef.current && editorRef.current.destroy) {
        editorRef.current.destroy();
        editorRef.current = null;
        isEditorReady.current = false;
      }
    };
  }, [formData.content]);

  const handleUploadImage = async () => {
    try {
      if (!file) return setImageUploadError("Please select an image");
      const data = new FormData();
      data.append("file", file);
      data.append("upload_preset", import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET);
      data.append("cloud_name", import.meta.env.VITE_CLOUDINARY_CLOUD_NAME);
      const res = await fetch(
        `https://api.cloudinary.com/v1_1/${import.meta.env.VITE_CLOUDINARY_CLOUD_NAME}/image/upload`,
        { method: "POST", body: data }
      );
      const result = await res.json();
      setImageFileUrl(result.url);
      setFormData((prev) => ({ ...prev, image: result.url }));
      setImageUploadError(null);
    } catch (err) {
      setImageUploadError("Image upload failed");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const savedContent = await editorRef.current.save();
      const payload = {
        ...formData,
        content: savedContent,
      };

      const res = await fetch(`${API_BASE_URL}/api/post/updatepost/${formData._id}/${currentUser._id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setPublishError(data.message);
        return;
      }
      navigate(`/post/${data.slug}`);
    } catch (error) {
      setPublishError("Failed to update post");
    }
  };

  return (
    <div className="p-3 max-w-3xl mx-auto min-h-screen">
      <h1 className="text-center text-3xl my-7 font-semibold">Update Post</h1>
      <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
        <div className="flex flex-col gap-4 sm:flex-row justify-between">
          <TextInput
            type="text"
            placeholder="Title"
            required
            value={formData.title || ""}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, title: e.target.value }))
            }
            className="flex-1"
          />
          <Select
            value={formData.category || "uncategorized"}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, category: e.target.value }))
            }
          >
            <option value="uncategorized">Select a category</option>
            <option value="javascript">JavaScript</option>
            <option value="reactjs">React.js</option>
            <option value="nextjs">Next.js</option>
          </Select>
        </div>

        <div className="flex gap-4 items-center justify-between border-4 border-teal-500 border-dotted p-3">
          <FileInput
            type="file"
            accept="image/*"
            onChange={(e) => setFile(e.target.files[0])}
          />
          <Button
            type="button"
            gradientDuoTone="purpleToBlue"
            size="sm"
            outline
            onClick={handleUploadImage}
            disabled={imageUploadProgress}
          >
            {imageUploadProgress ? (
              <div className="w-16 h-16">
                <CircularProgressbar
                  value={imageUploadProgress}
                  text={`${imageUploadProgress || 0}%`}
                />
              </div>
            ) : (
              "Upload Image"
            )}
          </Button>
        </div>

        {imageUploadError && <Alert color="failure">{imageUploadError}</Alert>}
        {formData.image && (
          <img
            src={formData.image}
            alt="upload"
            className="w-full h-72 object-cover"
          />
        )}

        <div id="editorjs" className="min-h-[300px] border border-gray-300 rounded-lg p-4" />

        <Button type="submit" gradientDuoTone="purpleToPink">
          Update Post
        </Button>

        {publishError && (
          <Alert className="mt-5" color="failure">
            {publishError}
          </Alert>
        )}
      </form>
    </div>
  );
}
