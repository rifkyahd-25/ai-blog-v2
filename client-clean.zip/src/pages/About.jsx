import React from 'react';

const About = () => {
  return (
    <div className="max-w-4xl mx-auto p-6 text-gray-800">
      <h1 className="text-3xl font-bold mb-6 text-center">About RRR Blog</h1>
      
      <div className="mb-6">
        <p className="text-lg leading-relaxed">
          Welcome to <strong>RRR Blog</strong>, your go-to destination for insightful articles, news, and practical tips covering technology, AI, blogging, career opportunities, and more.
        </p>
        <p className="text-lg mt-4 leading-relaxed">
          Our mission is to provide readers with accurate, up-to-date, and actionable content. Whether you’re a tech enthusiast, job seeker, or aspiring blogger, we strive to deliver valuable insights that help you stay informed, grow professionally, and succeed online.
        </p>
      </div>

      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-3">Our Vision</h2>
        <p className="text-lg leading-relaxed">
          Our vision is to become a trusted hub for knowledge and inspiration in the digital world. We aim to empower individuals and businesses with practical guidance, from tech news and AI trends to blogging tips and career advice, helping you make informed decisions and stay ahead in a rapidly evolving landscape.
        </p>
      </div>

      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-3">What We Cover</h2>
        <ul className="list-disc list-inside text-lg leading-relaxed">
          <li>Technology & AI: Latest news, trends, and innovations in the tech world.</li>
          <li>Career & Job Opportunities: Updates, tips, and advice for students and professionals.</li>
          <li>Blogging & Content Creation: Guides, tutorials, and strategies for successful blogging.</li>
          <li>Online Business & Marketing: Insights into growing, monetizing, and promoting online ventures.</li>
        </ul>
      </div>

      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-3">Why Choose RRR Blog?</h2>
        <p className="text-lg leading-relaxed">
          At RRR Blog, we focus on delivering content that is high-quality, relevant, and engaging. Our team of experienced writers and industry enthusiasts works diligently to bring you the latest updates, expert advice, and practical strategies that make a real impact.
        </p>
        <p className="text-lg mt-4 leading-relaxed">
          We continually adapt our content to meet the needs of our growing community. Whether you are exploring new technologies, seeking career guidance, or building your personal brand, RRR Blog has resources tailored for you.
        </p>
      </div>

      <div className="text-center mt-8">
        <h2 className="text-xl font-semibold mb-2">Join Our Community</h2>
        <p className="text-lg leading-relaxed mb-4">
          Explore our articles, share your thoughts, and engage with our community. Sign up to receive the latest updates directly to your inbox and never miss out on important tech news and career opportunities.
        </p>
        <a href="/contact" className="bg-blue-600 text-white py-2 px-6 rounded-full hover:bg-blue-700 transition-colors">
          Get In Touch
        </a>
      </div>
    </div>
  );
};

export default About;
