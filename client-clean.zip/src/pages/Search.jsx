import { Button, Select, TextInput } from "flowbite-react";
import { useEffect, useState, useCallback, useMemo } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import PostCard from "../components/PostCard";
import { API_BASE_URL } from "../utils/apiConfig";

// Skeleton loader for post cards
const PostSkeleton = () => (
  <div className="w-72 bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden animate-pulse">
    {/* Image placeholder */}
    <div className="h-40 bg-gray-200 dark:bg-gray-700" />

    {/* Text placeholders */}
    <div className="p-4 space-y-3">
      <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-3/4" />
      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full" />
      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-5/6" />
    </div>
  </div>
);

export default function Search() {
  const [sidebarData, setSidebarData] = useState({
    searchTerm: "",
    sort: "desc",
    category: "uncategorized",
  });
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showMore, setShowMore] = useState(false);
  const [error, setError] = useState("");

  const location = useLocation();
  const navigate = useNavigate();

  const fetchPosts = useCallback(async (extraParams = {}) => {
    setLoading(true);
    setError("");
    try {
      const urlParams = new URLSearchParams(location.search);
      Object.entries(extraParams).forEach(([key, value]) =>
        urlParams.set(key, value)
      );
      const res = await fetch(
        `${API_BASE_URL}/api/post/getposts?${urlParams.toString()}`
      );
      if (!res.ok) throw new Error("Failed to fetch posts");
      const data = await res.json();
      setPosts((prev) =>
        extraParams.startIndex ? [...prev, ...data.posts] : data.posts
      );
      setShowMore(data.posts.length === 9);
    } catch (err) {
      setError(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }, [location.search]);

  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    setSidebarData((prev) => ({
      ...prev,
      searchTerm: urlParams.get("searchTerm") || "",
      sort: urlParams.get("sort") || "desc",
      category: urlParams.get("category") || "uncategorized",
    }));
    fetchPosts();
  }, [location.search, fetchPosts]);

  const handleChange = useCallback((e) => {
    const { id, value } = e.target;
    setSidebarData((prev) => ({ ...prev, [id]: value || prev[id] }));
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    const urlParams = new URLSearchParams();
    Object.entries(sidebarData).forEach(([key, value]) =>
      urlParams.set(key, value)
    );
    navigate(`/search?${urlParams.toString()}`);
  };

  const handleShowMore = () => {
    fetchPosts({ startIndex: posts.length });
  };

  const isFormValid = useMemo(
    () => sidebarData.searchTerm || sidebarData.category !== "uncategorized",
    [sidebarData]
  );

  return (
    <div className="flex flex-col md:flex-row">
      {/* Sidebar */}
      <div className="p-7 border-b md:border-r md:min-h-screen border-gray-500">
        <form className="flex flex-col gap-8" onSubmit={handleSubmit}>
          <div className="flex items-center gap-2">
            <label htmlFor="searchTerm" className="whitespace-nowrap font-semibold">
              Search Term:
            </label>
            <TextInput
              placeholder="Search..."
              id="searchTerm"
              type="text"
              value={sidebarData.searchTerm}
              onChange={handleChange}
            />
          </div>
          <div className="flex items-center gap-2">
            <label htmlFor="sort" className="font-semibold">Sort:</label>
            <Select id="sort" onChange={handleChange} value={sidebarData.sort}>
              <option value="desc">Latest</option>
              <option value="asc">Oldest</option>
            </Select>
          </div>
          <div className="flex items-center gap-2">
            <label htmlFor="category" className="font-semibold">Category:</label>
            <Select
              id="category"
              onChange={handleChange}
              value={sidebarData.category}
            >
              <option value="uncategorized">Uncategorized</option>
              <option value="reactjs">React.js</option>
              <option value="nextjs">Next.js</option>
              <option value="javascript">JavaScript</option>
            </Select>
          </div>
          <Button
            type="submit"
            outline
            gradientDuoTone="purpleToPink"
            disabled={!isFormValid}
          >
            Apply Filters
          </Button>
        </form>
      </div>

      {/* Posts Section */}
      <div className="w-full">
        <h1 className="text-3xl font-semibold sm:border-b border-gray-500 p-3 mt-5">
          Posts results:
        </h1>
        <div className="p-7 flex flex-wrap gap-4">
          {error && <p className="text-red-500">{error}</p>}
          {loading && !posts.length && Array.from({ length: 6 }).map((_, i) => (
            <PostSkeleton key={i} />
          ))}
          {!loading && !posts.length && !error && (
            <p className="text-xl text-gray-500">No posts found.</p>
          )}
          {posts.map((post) => (
            <PostCard key={post._id} post={post} />
          ))}
          {showMore && !loading && (
            <button
              onClick={handleShowMore}
              className="text-teal-500 text-lg hover:underline p-7 w-full"
            >
              Show More
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
