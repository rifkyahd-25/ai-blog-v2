import { useState, useEffect, useRef } from "react";
import EditorJS from "@editorjs/editorjs";
import Header from "@editorjs/header";
import List from "@editorjs/list";
import Paragraph from "@editorjs/paragraph";
import { Alert, Button, TextInput, FileInput, Textarea } from "flowbite-react";
import { CircularProgressbar } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";
import { useNavigate } from "react-router-dom";
import { API_BASE_URL } from "../utils/apiConfig";

export default function CreateJob() {
  const editorRef = useRef(null);
  const [formData, setFormData] = useState({});
  const [publishError, setPublishError] = useState(null);
  const navigate = useNavigate();

  // Editor.js init for job description
  useEffect(() => {
    if (!editorRef.current) {
      editorRef.current = new EditorJS({
        holder: "editorjs",
        tools: {
          header: Header,
          list: List,
          paragraph: Paragraph,
        },
        placeholder: "Write job description here...",
        data: formData.description || {},
      });
    }

    return () => {
      if (editorRef.current?.destroy) {
        editorRef.current.destroy();
        editorRef.current = null;
      }
    };
  }, [formData.description]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!editorRef.current) return;

    const savedData = await editorRef.current.save();

    const payload = {
      ...formData,
      description: savedData,
    };

    try {
      const res = await fetch(`${API_BASE_URL}/api/job/create`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      const data = await res.json();
      if (!res.ok) {
        setPublishError(data.message || "Job creation failed");
        return;
      }
      navigate(`/job`);
    } catch {
      setPublishError("Job creation failed");
    }
  };

  return (
    <div className="p-3 max-w-3xl mx-auto min-h-screen">
      <h1 className="text-center text-3xl my-7 font-semibold">Create a Job</h1>
      <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
        <TextInput
          type="text"
          placeholder="Job Title"
          required
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
        />

        <TextInput
          type="text"
          placeholder="Company Name"
          required
          onChange={(e) => setFormData({ ...formData, company: e.target.value })}
        />

        <TextInput
          type="text"
          placeholder="Location (e.g., Remote, Colombo)"
          onChange={(e) => setFormData({ ...formData, location: e.target.value })}
        />

        <select
          onChange={(e) => setFormData({ ...formData, type: e.target.value })}
          className="border rounded p-2"
        >
          <option value="Full-time">Full-time</option>
          <option value="Part-time">Part-time</option>
          <option value="Internship">Internship</option>
          <option value="Contract">Contract</option>
        </select>

        <TextInput
          type="text"
          placeholder="Application Link"
          onChange={(e) => setFormData({ ...formData, applyLink: e.target.value })}
        />

        <Textarea
          placeholder="Requirements (comma separated)"
          onChange={(e) =>
            setFormData({ ...formData, requirements: e.target.value.split(",") })
          }
        />

        {/* Job Description */}
        <div
          id="editorjs"
          className="min-h-[300px] border border-gray-300 rounded-lg p-4"
        />

        <Button type="submit" gradientDuoTone="purpleToPink">
          Publish Job
        </Button>

        {publishError && (
          <Alert className="mt-5" color="failure">
            {publishError}
          </Alert>
        )}
      </form>
    </div>
  );
}
