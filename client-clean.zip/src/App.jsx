import { BrowserRouter, Routes, Route } from "react-router-dom";
import React, { Suspense, lazy } from "react";
import { HelmetProvider } from "react-helmet-async"; // Add this import

// Eager load critical components
import Header from "./components/Header";

// Lazy load non-critical components/pages
const SignUp = lazy(() => import("./pages/SignUp"));
const Signin = lazy(() => import("./pages/Signin"));
const Home = lazy(() => import("./pages/Home"));
const Search = lazy(() => import("./pages/Search"));
const PostPage = lazy(() => import("./pages/PostPage"));
const About = lazy(() => import("./pages/About"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const CreatePost = lazy(() => import("./pages/CreatePost"));
const UpdatePost = lazy(() => import("./pages/UpdatePost"));
const PrivateRoute = lazy(() => import("./components/PrivateRoute"));
const OnlyAdminPrivateRoute = lazy(() => import("./components/OnlyAdminPrivateRoute"));
const Footer = lazy(() => import("./components/Footer"));
const ScrollToTop = lazy(() => import("./components/ScrollToTop"));

const TermsConditions = lazy(() => import("./pages/TermsConditions"));
const Contact = lazy(() => import("./pages/Contact"));
import CreateJob from "./pages/CreateJob";
import JobListings from "./pages/JobListings";
import UpdateJob from "./pages/UpdateJob";
import PrivacyPolicy from "./pages/PrivacyPolicy";

function App() {
  return (
    <HelmetProvider> {/* Add this wrapper */}
      <BrowserRouter>
        <ScrollToTop />
        <Header />
        <Suspense fallback={<div className="flex justify-center items-center min-h-screen">Loading...</div>}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/sign-up" element={<SignUp />} />
            <Route path="/sign-in" element={<Signin />} />
            <Route path="/search" element={<Search />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/job" element={<JobListings />} />
            <Route path="/post/:postSlug" element={<PostPage />} />
            <Route path="/about" element={<About />} />
            <Route path="/privacy" element={<PrivacyPolicy />} />
            <Route path="/termsandcondition" element={<TermsConditions />} />

            <Route element={<PrivateRoute />}>
              <Route path="/dashboard" element={<Dashboard />} />
            </Route>
            
            <Route element={<OnlyAdminPrivateRoute />}>
              <Route path="/create-job" element={<CreateJob />} />
              <Route path="/create-post" element={<CreatePost />} />
              <Route path="/update-post/:postId" element={<UpdatePost />} />
              <Route path="/update-job/:jobId" element={<UpdateJob />} />
            </Route>
          </Routes>
        </Suspense>
        <Footer />
      </BrowserRouter>
    </HelmetProvider>
  );
}

export default App;